import { LightningElement, api } from 'lwc';

export default class Desktop extends LightningElement {
    @api passedInValue;
}
