import { LightningElement, api } from 'lwc';

export default class Mobile extends LightningElement {
    @api passedInValue;
}
